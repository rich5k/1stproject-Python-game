import pygame
from pygame.locals import*
import sys
import random
#turns on all of pygame
pygame.init()

#create a window for the game
width = 500
height = 480
win = pygame.display.set_mode((width, height))


#names the title of game
pygame.display.set_caption("Dodge the police")

# creates frame for the background
bg = pygame.image.load('BG City1.jpg').convert()


#for two different background images so that it doesn't go blank
bgX = 0
bgX2 = bg.get_width()

#creates object to help track time
clock = pygame.time.Clock()

# variable to keep track of players score
score = 0

# sound for when character is caught
caughtSound = pygame.mixer.Sound('handcuffs.wav')


#sound for a hovering helicopter
hoveringSound = pygame.mixer.Sound('hover.wav')

#sound for background music
bg_music = pygame.mixer.music.load('136_full_game-of-life_0222_preview.mp3')
#repeats background music
pygame.mixer.music.play(-1)

#creates class for the player
class player(object):
    #creates frames for player()running right,sliding and jumping
    walkRight = [pygame.image.load('Rrun1.png'), pygame.image.load('Rrun2.png'), pygame.image.load('Rrun3.png'), pygame.image.load('Rrun4.png'), pygame.image.load('Rrun5.png'), pygame.image.load('Rrun6.png')]
    jump = [pygame.image.load('Rjump1.png'), pygame.image.load('Rjump2.png'), pygame.image.load('Rjump3.png'), pygame.image.load('Rjump4.png'), pygame.image.load('Rjump5.png'), pygame.image.load('Rjump6.png'),pygame.image.load('Rjump7.png')]
    slide = [pygame.image.load('S1.png'), pygame.image.load('S2.png'),pygame.image.load('S2.png'),pygame.image.load('S3.png'),pygame.image.load('S3.png'),pygame.image.load('S3.png'),pygame.image.load('S3.png'), pygame.image.load('S3.png'), pygame.image.load('S4.png'), pygame.image.load('S5.png')]
##    fall = [pygame.image.load('S3.png')]
    # helps character jump at correct speed
    jumpList = [1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,-1,-1,-1,-1,-1,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-3,-3,-3,-3,-3,-3,-3,-3,-3,-3,-3,-3,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4,-4]

    
    def __init__(self, x, y, width, height):
        self.x =x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.isJump = False
        self.jumpCount = 0
        #self.left = False
        self.right = 0
        self.walkCount = 0
        self.sliding = False
        self.slideCount = 0
        self.health = 10
        self.slideUp= False
        #self.falling = False

    def draw(self,win):

        if self.isJump:
            #help character to jump high
            self.y -= self.jumpList[self.jumpCount] *1.2
            win.blit(self.jump[self.jumpCount//18], (self.x, self.y))
            self.jumpCount += 1
            if self.jumpCount > 108:
                self.jumpCount = 0
                self.isJump = False
                self.right = 0
            self.hitbox = (self.x + 50, self.y+100, self.width, self.height)
        elif self.sliding or self.slideUp:
            if self.slideCount < 20:
                self.y += 1
            elif self.slideCount == 70:
                self.y -= 19
                
            #if character is lying down
            elif self.slideCount > 20 and self.slideCount < 80:
                self.hitox= (self.x,self.y+3, self.width, self.height)
                
            if self.slideCount >= 100:
                self.slideCount = 0
                self.sliding = False
                self.hitbox = (self.x+50, self.y+100, self.width , self.height)
                self.runCount = 0
            win.blit(self.slide[self.slideCount//10], (self.x, self.y))
            
            self.slideCount += 1

           


        else:
            if self.right > 42:
                self.right = 0
            win.blit(self.walkRight[self.right//8], (self.x, self.y))
            self.right += 1
            self.hitbox = (self.x +55, self.y+100, self.width+5 , self.height +25)


        pygame.draw.rect(win, (255,0,0), (self.hitbox[0] , self.hitbox[1] -10, 50, 10))
        pygame.draw.rect(win, (0,120,0), (self.hitbox[0], self.hitbox[1] -10, 50 - ((50/10)* (10- self. health)), 10))
        #pygame.draw.rect(win, (255,0,0), self.hitbox, 2)

    def hit(self):
        if self.health > 0:
            self.health -= 1

        else:
            self.visible = False
        print('hit')

        
#creates class for the police
class enemy(object):
    walkRight = [pygame.image.load('PRattack1_.png'), pygame.image.load('PRattack2_.png'), pygame.image.load('PRattack3_.png'), pygame.image.load('PRattack4_.png'), pygame.image.load('PRattack5_.png'), pygame.image.load('PRattack6_.png'), pygame.image.load('PRwalk7.png'), pygame.image.load('PRwalk8.png')]
    walkLeft = [pygame.image.load('PLattack1_.png'), pygame.image.load('PLattack2_.png'), pygame.image.load('PLattack3_.png'), pygame.image.load('PLattack4_.png'), pygame.image.load('PLattack5_.png'), pygame.image.load('PLattack6_.png'), pygame.image.load('PLwalk7.png'), pygame.image.load('PLwalk8.png')]

    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.walkCount = 0
        self.vel = 2
        
        self.hitbox = (self.x + 17, self.y + 2, 31, 57)
        self.visible = True

    def draw(self,win):
        if self.visible:
            if self.walkCount + 1 >= 33:
                self.walkCount = 0



            else:
                win.blit(self.walkLeft[self.walkCount // 6], (self.x, self.y))
                self.walkCount += 1

            self.hitbox =  (self.x , self.y +10 , self.width+50, self.height+200)
            #pygame.draw.rect(win, (255,0,0), self.hitbox, 2)


    def hit(self,rect):
        #checks if the x coordinates of player and enemy hitbox are within each other
        if rect[0] + rect[2] > self .hitbox[0] and rect[0] < self.hitbox[0]+ self.hitbox[2]:
            if rect[1] + rect[3] > self.hitbox[3]:
                return True
        return False

class helicopter(object):
    moving = [pygame.image.load('H1.png'), pygame.image.load('H2.png'), pygame.image.load('H3.png'), pygame.image.load('H4.png'), pygame.image.load('H5.png'), pygame.image.load('H6.png'), pygame.image.load('H7.png'), pygame.image.load('H8.png')]
   
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.flyCount = 0
        self.vel = 2
        self.hitbox = (x, y, width, height)
        self.visible = True
        self.isFly = True

    def draw(self,win):
        
        if self.visible:
            if self.flyCount + 1 >= 8:
                self.walkCount = 0
       
        win.blit(pygame.transform.scale(self.moving[self.flyCount//50], (122,150)), (self.x, self.y))
        self.flyCount += 1
        if self.flyCount > 108:
                self.flyCount = 0
                self.isFly = False
        self.hitbox =  (self.x , self.y , self.width+50, self.height+50)
        #pygame.draw.rect(win, (255,0,0), (self.hitbox), 2)

    def hit(self,rect):
        #checks if the y coordinates of player and helicopter hitbox are within each other
        
        if self.hitbox[1] < rect[1] + rect[3] and self.hitbox[1] + self.hitbox[3] > rect[1]:
            if self.hitbox[0] + self.hitbox[2] > rect[0] and self.hitbox[0] < rect[0] + rect[2]:
                return True
        return False

#function draws charcters and background on the screen       
def redrawGameWindow():
    rel_x =bgX %bg.get_rect().width
    win.blit(bg, (rel_x-bg.get_rect().width,0))
    
    # when rel_x is less than width of screen
    if rel_x < width:
        win.blit(bg,(rel_x, 0))
    win.blit(bg, (bgX2, 0))
    text = font.render("Score: " + str(score), 1, (0,0,0))
    win.blit(text, (350,10))
    boy.draw(win)
    for object in objects:
        object.draw(win)

    pygame.display.update()

#function to update scores file
def updateScorefile():
    s = open('scores.txt', 'r')
    file = s.readlines()
    last = int(file[0])

    # if current score is higher than previous score, write new score to file
    if last < int(score):
        s.close()
        s_file = open('scores.txt', 'w')
        s_file.write(str(score))
        s_file.close()

        # if current score is higher, return it
        return score
    
    #else return previous one
    return last

# function to end the game
def gameover():
   global objects, speed,score
   objects = []
   speed = 30
   run= True
   while run:
        # delay so that quit is slowed down
        #pygame.time.delay(100)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()
            #when mouse button is pressed, exit loop, then exit function
            if event.type == pygame.MOUSEBUTTONDOWN:
                run = False
                boy.health = 10
        #resets the screen
        win.blit(bg, (0,0))
        largeFont = pygame.font.SysFont('arial', 50)
        previousScore = largeFont.render('Previous Score: ' +str(updateScorefile()),1, (255,255,255))
        #prints previous score in the middle of the screen
        win.blit(previousScore, (width/2- previousScore.get_width()/2, 100))
        #prints current score in the middle of the screen
        presentScore= largeFont.render('Your Score: ' + str(score),1, (255,255,255))
        win.blit(presentScore, (width/2- presentScore.get_width()/2, 200))
        pygame.display.update()
    
   score = 0
    
#main loop
#creates font object from system fonts
font = pygame.font.SysFont("arial", 30, True, True)

boy = player(100, 200,64,64)


 #every half second, speed is going to increase
pygame.time.set_timer(USEREVENT+1,500)

#a police and helicopter appear every 5-7 secs
pygame.time.set_timer(USEREVENT+2, random.randrange(5000,7000))
speed = 30
run = True

objects = []
while run:
    
    for object in objects:
        if object.hit(boy.hitbox):
            boy.hit()
            # if player life is down, game over
            if boy.health == 0:
                caughtSound.play()
                gameover() 
        #makes characters move to the leftt
        object.x -=1.4
        if object.x< object.width * -1:
            objects.pop(objects.index(object))
    #moves background back at every frame
    bgX -= 1.6
    bgX -=1.6

    #so 1st background would start at (0,0) and it moves backwards until it reaches a neg number
    if bgX < bg.get_width() * -1:
        #this resets the screen
        bgX = bg.get_width()
    #so when the first is about to go off-screen ,this will be coming on the screen to show that it's moving
    if bgX2 < bg.get_width() * -1:
        bgX2 = bg.get_width()
    
    

    #event loop   
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()
            sys.exit()
        # speed increase every few secs
        if event.type ==USEREVENT+1:
            speed += 1

        if event.type ==USEREVENT+2:
            r = random.randrange(0,2)
            if r == 0:
            #appends number of helicopters to objects list
                objects.append(helicopter(800, 60, 40, 64))
                hoveringSound.play()
            else:
                #appends number of helicopters to objects list
                objects.append(enemy(600, 250, 40, 40))
        
    #frames per minute
    clock.tick(speed)
    for time in range(clock.tick(1000000)):
        score += 1
        score//5-6
    

    
    #creates a list of boolean for the state of keyboard keys
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE] or keys[pygame.K_UP]:
        if not(boy.isJump) and boy.jumpCount == 0:
            boy.isJump = True
            
            
    if keys[pygame.K_DOWN]:
        if not(boy.sliding):
            boy.sliding = True
            
    if keys[pygame.K_LEFT] and boy.x >boy.vel:
        boy.x -= boy.vel
        boy.left = True
        boy.right = False
        boy.standing = False

    elif keys[pygame.K_RIGHT] and boy.x < 500 - boy.width - boy.vel:
        boy.x += boy.vel
        boy.left = False
        boy.right = True
        boy.standing = False



    redrawGameWindow()

pygame.quit()
        
